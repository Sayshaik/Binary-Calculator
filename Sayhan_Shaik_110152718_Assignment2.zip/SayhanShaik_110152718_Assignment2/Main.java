package Main;

public class Main {
	public static void main(String[] args) {
		
	Politician trudeau = new Politician("Justin Trudeau", new Date(25,12,1971),1,"Liberal"); 
	
	Player Ronaldo = new Player("Cristiano Ronaldo", new Date(5,2,1985),2,"Soccer","Al Nassr");  // three names 
	
	Politician pierre = new Politician("Pierre Poilievre", new Date(3,6,1979),3,"Conservative");
	
	GuessMaker2 game = new GuessMaker2(); //starting a game
	
	game.addPerson(trudeau);
	game.addPerson(Ronaldo);
	game.addPerson(pierre);
	
	game.startGame();
	}
	
}// this assignment was really fun to code and love you guys as our TA. Keep up the great work whooooooo fwaaeeehh
