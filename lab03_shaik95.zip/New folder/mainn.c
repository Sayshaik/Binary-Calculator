#include <stdio.h>
#define MAX 8

void func_and(int a[], int b[], int result[]){
	for(int i=0; i < MAX; i = i + 1){
		  result[i] = a[i] & b[i];
	}
}
void func_or(int a[], int b[], int result[]){
     for(int i=0; i < MAX; i = i + 1){
          result[i] = a[i] | b[i];
       }
 }
void func_not(int a[], int result[]){
     for(int i=0; i < MAX; i = i + 1){
	     if(a[i]==1){
		     result[i]=0;
	     }
	     else{
		     result[i]=1;
	     }
}
}
void func_1s_comp(int a[], int result[]){
    func_not(a,result);
}
void func_2s_comp(int a[], int result[]){
    int forone[MAX] = {0};
    forone[MAX-1] = 1; 

    int ones_comp[MAX];
    func_1s_comp(a, ones_comp);

    int carryover = 1;
    for (int i = MAX-1; i >= 0; i--) {
        int sum = ones_comp[i] + carryover;
        result[i] = sum % 2; 
        carryover = sum / 2; 
    }
}
void func_2s_comp_star(int a[], int result[]) {
    int findingOne= 0; 
    for (int i = MAX - 1; i >= 0; i--) {
        if (findingOne) {
            result[i] = a[i] == 1 ? 0 : 1;
        } else {
            result[i] = a[i];
            if (a[i] == 1) {
                findingOne = 1; 
            }
        }
    }
}

void get_inp(int arr[]) {
    for (int i = 0; i < MAX; i++) {
        int val = 0;
        while (!val) {
            printf("Enter bit %d (0 or 1): ", i + 1);
            scanf("%d", &arr[i]);
            if (arr[i] == 0 || arr[i] == 1) {
                val= 1;
            } else {
                printf("Error: Please enter 0 or 1 only!\n");
            }
        }
    }
}
int main(void){

	int command = -1;
        while (command != 0) {
          printf("0-Exit\n1-AND\n2-OR\n3-NOT\n4-1's Complement\n5-2's Complement\n6-2's Complement*\n");
          scanf("%d", &command);
	  switch(command){
			case 0:
				printf("\nThankyou for Using this program\n");
				break;
			case 1:
		        	int first[MAX];
                                int second[MAX];
                                printf("Enter the First Binary Number:\n");
				get_inp(first);
				printf("Enter the Second Binary Number:\n");
				get_inp(second);
                                int x[MAX];
                                func_and(first,second, x);
                                printf("The first number AND second binary yield:\n"); 
                                for(int i=0; i < MAX; i = i + 1){
    	                                printf("%d", x[i]);
	                              }
                                   printf("\n");
				   break;
			case 2:
		        	int third[MAX];
                                int fourth[MAX];
                                printf("Enter the First Binary Number:\n");
                                get_inp(third);
                                printf("Enter the second binary number:\n");
                                get_inp(fourth);
                                int y[MAX];
                                func_or(third, fourth, y);
                                for(int i=0; i < MAX; i = i + 1){
    	                           printf("%d", y[i]);
	                              }
               
				break;
			case 3:
				int fifth[MAX];
				int z[MAX];
				printf("Enter a Binary Number:\n");
				get_inp(fifth);
				func_not(fifth,z);
				printf("Binary Number:\n");
				for(int i=0; i < MAX; i = i + 1){
					printf("%d", z[i]);
				}
				printf("\n");
				break;
			case 4:
				int sixth[MAX];
				int f[MAX];
				printf("Enter a Binary Number:\n");
				get_inp(sixth);
				func_1s_comp(sixth,f);
				printf("1's Complement of the Binary Number:");
				for(int i=0; i < MAX; i = i + 1){
					printf("%d", f[i]);
				}
				printf("\n");
				break;
			case 5:
				int seventh[MAX];
				int g[MAX];
				printf("Enter a Binary Number:\n");
				get_inp(seventh);
				func_2s_comp(seventh,g);
				printf("2's Complement of the Binary Number is :" );
				for (int i=0; i<MAX; i=i+1){
					printf("%d", g[i]);
				}
				printf("\n");
				break;
			case 6:
				int eigth[MAX];
				int j[MAX];
				printf("Enter a Binary Number:\n");
				get_inp(eigth);
				func_2s_comp_star(eigth,j);
				printf("2's Complement using the Alternative Method is:");
				for (int i=0; i<MAX; i=i+1){
					printf("%d", j[i]);
				}
				printf("\n");
				break;
		}
	}
	return 0;
}

