package Main;
// Name:Sayhan Shaik 
//Computer Science
//Assignment 2 for java
public class Player extends Person {
  private String game;
  private String team;

  public Player(String name, Date birthday, int difficulty, String game, String team) {
      super(name, birthday, "Unknown", difficulty);
      this.game = game;
      this.team = team;
  }

  public Player(Player other) { // public methods
      super(other);
      this.game = other.game;  
      this.team = other.team;
  }
 
  @Override
  public String personType() {  // overriden methods
      return "Player";
  }

  @Override
  public Person clone() {
      return new Player(this);
  }

  @Override
  public String toString() {// to string method
      return super.toString() + ". " + getName() + " is a Player of Team " + team + ".";
  }

  public String getGame() {// below two are getter methods
      return game;
  }
  
  public String getTeam() {
      return team;
  }
}

