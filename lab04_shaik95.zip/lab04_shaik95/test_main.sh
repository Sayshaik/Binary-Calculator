#!/bin/bash
echo "start building main program:"
echo "compiling to assembly lines ..."
cc main.c -S
cc increment.c -S
echo "translating to opcodes ..."
cc main.s -c
cc increment.s -c
echo "statically linking all required opcodes ..."
cc main.o increment.o -o main
echo "build successfully done!"
#echo "running the main program"
#./main
#echo "running the main for input 4:"
#./main <<< 4
#echo "running the main for input 10:"
#./main <<< 10
#!/bin/bash

#initializing counters
passing=0;
failing=0;
# Reads the test inputs and expected outputs from test_inputs.txt
while IFS=',' read -r input expected_output; do

    # Remove leading and trailing single quotes and whitespace from input and expected_output
    input=$(echo "$input" | sed "s/^'//;s/'$//" | xargs)
    expected_output=$(echo "$expected_output" | sed "s/^'//;s/'$//" | xargs)

    # Run the program with the input and capture the output
    program_output=$(echo "$input" | ./main | xargs)

    # Compare the program output with the expected output
    if [ "$program_output" == "$expected_output" ]; then
        passing=$((passing + 1))
	echo "Input: $input, main: $program_output, correct: $expected_output ==> passing"
    else
        failing=$((failing + 1))
	echo "Input: $input, main: $program_output, correct: $expected_output ==> failing"
    fi



done < testinginputs.txt

# Display summary of passed and failed tests
echo "total passed: $passing"
echo "total failed: $failing"

