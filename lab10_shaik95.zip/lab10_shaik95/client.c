#include <stdlib.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

#define MAX_BUFFER 1024

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s <IP> <Port>\n", argv[0]);
        exit(1);
    }

    int domain = AF_INET;
    int type = SOCK_STREAM;
    int protocol = 0;

    int client_sd = socket(domain, type, protocol);
    if (client_sd == -1) {
        perror("Error creating socket for client");
        exit(1);
    }

    printf("Client socket created with descriptor: %d\n", client_sd);

    struct in_addr server_sin_address;
    server_sin_address.s_addr = inet_addr(argv[1]);
    int server_sin_port = htons(atoi(argv[2]));

    struct sockaddr_in server_sin;
    server_sin.sin_family = domain;
    server_sin.sin_addr = server_sin_address;
    server_sin.sin_port = server_sin_port;

    if (connect(client_sd, (struct sockaddr *) &server_sin, sizeof(server_sin)) == -1) {
        perror("Error connecting to server");
        exit(1);
    }

    printf("Connected to server at %s:%d\n", argv[1], ntohs(server_sin.sin_port));

    while (1) {
        int x, y;
        char username[50], password[50];
        
        printf("Enter first number (or -1 to quit): ");
        scanf("%d", &x);
        if (x == -1) break;

        printf("Enter second number: ");
        scanf("%d", &y);

        printf("Enter username: ");
        scanf("%s", username);
        printf("Enter password: ");
        scanf("%s", password);

        char buffer[MAX_BUFFER];
        snprintf(buffer, sizeof(buffer), "%s %s %d %d", username, password, x, y);
        send(client_sd, buffer, strlen(buffer), 0);

        int bytes_received = recv(client_sd, buffer, sizeof(buffer), 0);
        if (bytes_received > 0) {
            buffer[bytes_received] = '\0'; 
            printf("Server Response: %s\n", buffer);
        }
    }

    close(client_sd);
    return 0;
}




