package Main;

import java.util.ArrayList;
import java.util.Scanner;

public class GuessMaker2 {
    private ArrayList<Person> persons; // List of persons to guess from
    private int currentPerson; // Index of the current person 

    // Constructor to create an array list
    public GuessMaker2() {
        persons = new ArrayList<>();
        currentPerson = -1;
    }

    // Adding a Person to the list
    public void addPerson(Person person) {
        persons.add(person);
    }

    // Set the current person index and check for validity
    public void setCurrentPerson(int index) {
        if (index >= 0 && index < persons.size()) {
            currentPerson = index;
        } else {
            System.out.println("Invalid person index.");
        }
    }

    // Getter for current person
    public Person getCurrentPerson() {
        if (currentPerson >= 0 && currentPerson < persons.size()) {
            return persons.get(currentPerson);
        } else {
            return null;
        }
    }

    // Start the game ( the main method here)
    public void startGame() {
        if (persons.isEmpty()) { //check if the list is empty first
            System.out.println("No persons available for guessing. Add persons to start the game.");
            return;
        }

        Scanner scanner = new Scanner(System.in);//input ur person from the list

        System.out.println("Starting the GuessMaker2 Game!");
        boolean keepPlaying = true;

        while (keepPlaying) {
            // Loop through each person
            for (int i = 0; i < persons.size(); i++) {
                setCurrentPerson(i); // Set the current person
                Person person = getCurrentPerson();

                if(person == null) {
                    continue; //quit the loop once no more person left in the list
                }

                // Display welcome message
                System.out.println(person.welcomeMessage());

                // Prompt the user to guess the birthday
                boolean guessedCorrectly = false;

                while (!guessedCorrectly) {
                    System.out.print("Enter the guessed birthday (DD/MM/YYYY) or type 'quit' to exit: ");
                    String guessedBirthdayStr = scanner.nextLine().trim();

                    if (guessedBirthdayStr.equalsIgnoreCase("quit")) {
                        System.out.println("Thanks for playing! Exiting the program...");
                        scanner.close();
                        return;
                    }

                    try {
                        // Parse the guessed date using custom Date class
                        Date guessedBirthday = new Date(guessedBirthdayStr);

                        // Retrieve the actual birthday
                        Date actualBirthday = person.getBirthday();

                        // Check if the guess is correct
                        if (guessedBirthday.equals(actualBirthday)) {
                            System.out.println(person.successMessage());
                            guessedCorrectly = true;
                        } else {
                            // Provide hints based on difficulty level
                            provideHint(actualBirthday, guessedBirthday, person.getDifficulty());
                        }
                    } catch (Exception e) {
                        System.out.println("Invalid date format. Please use DD/MM/YYYY or MMM DD, YYYY.");
                    }
                }
            }

            // Ask if the player wants to play again
            System.out.print("Do you want to play again? (yes/no): ");
            String response = scanner.nextLine().trim().toLowerCase();
            keepPlaying = response.equals("yes");
        }

        System.out.println("Thank you for playing GuessMaker2!");
        scanner.close();
    }

    // Provide hints based on difficulty
    private void provideHint(Date actualBirthday, Date guessed, int difficulty) {
        // Compare years
        if (difficulty >= 1) {
            if (guessed.getYear() < actualBirthday.getYear()) {
                System.out.println("Hint: The birthday is in a later year.");
            } else if (guessed.getYear() > actualBirthday.getYear()) {
                System.out.println("Hint: The birthday is in an earlier year.");
            }
        }

        // Compare months
        if (difficulty >= 2) {
            if (guessed.getYear() == actualBirthday.getYear()) {
                if (guessed.getMonth() < actualBirthday.getMonth()) {
                    System.out.println("Hint: The birthday is in a later month.");
                } else if (guessed.getMonth() > actualBirthday.getMonth()) {
                    System.out.println("Hint: The birthday is in an earlier month.");
                }
            }
        }

        // Compare days
        if (difficulty == 3) {
            if (guessed.getYear() == actualBirthday.getYear() && guessed.getMonth() == actualBirthday.getMonth()) {
                if (guessed.getDay() < actualBirthday.getDay()) {
                    System.out.println("Hint: The birthday is on a later day.");
                } else if (guessed.getDay() > actualBirthday.getDay()) {
                    System.out.println("Hint: The birthday is on an earlier day.");
                }
            }
        }
    }

	
}
