#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <sys/wait.h>

int main(int argc, char *argv[]) {
    if (argc != 4) {
        fprintf(stderr, "Usage: %s <mainOperation> <operation1> <operation2>\n", argv[0]);
        return 1;
    }

    char *mainOperation = argv[1];
    char *operation1 = argv[2];
    char *operation2 = argv[3];

    printf("exec_math_bs pid: %d\n", getpid());
    char sourceCode[1024];
    snprintf(sourceCode, sizeof(sourceCode),
        "#include <stdio.h>\n"
        "#include <stdlib.h>\n"
	"#include <string.h>\n"
        "int main(int argc, char *argv[]) {\n"
        "    int a = atoi(argv[1]);\n"
        "    int b = atoi(argv[2]);\n"
        "    int result = 0;\n"
        "    if (strcmp(argv[0], \"+\") == 0) result = a + b;\n"
        "    else if (strcmp(argv[0], \"-\") == 0) result = a - b;\n"
        "    else if (strcmp(argv[0], \"*\") == 0) result = a * b;\n"
        "    else if (strcmp(argv[0], \"/\") == 0) result = a / b;\n"
        "    printf(\"%%d %%s %%d = %%d\\n\", a, argv[0], b, result);\n"
        "    return 0;\n"
        "}\n"
    );


    int fd = open("math.c", O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (fd == -1) {
        perror("Error creating source file");
        return 1;
    }


    printf("fd for math.c file: %d\n", fd);
    write(fd, sourceCode, strlen(sourceCode));
    close(fd);

    if (fork() == 0) {
        execlp("gcc", "gcc", "math.c", "-o", "math_program", (char *) NULL);
        perror("Compilation failed");
        return 1;
    }
    wait(NULL);
    if (fork() == 0) {
        printf("math pid: %d\n", getpid());
        char *Newargv[] = {mainOperation, operation1, operation2, NULL}; 
        char *newenviron[] = {NULL};
        fexecve(open("math_program", O_RDONLY), Newargv, newenviron);
       
        perror("Execution failed");
        return 1;
    }
    wait(NULL);

    remove("math.c");
    remove("math_program");

    return 0;
}

