package Main;

public class Politician extends Person {
	
	private String party;
	
	public Politician(String name, Date birthday, int difficulty, String party) { //constructors 
		super(name,birthday,"N/A",difficulty);
		this.party=party;
	}
	
	public Politician(Politician another) {  
		super(another);
		this.party=another.party;
	}
	
	@Override
	public String personType() {
		return "Politician";
	}
	
	@Override
	public Person clone() { // cloning 
		return new Politician(this);
	}
	
	@Override
	public String toString() {
        return super.toString() + ". " + getName() + " is a member of the " + party + " party.";
	}
	
	public String getParty() { //getter methods
		return party;
	}
}
