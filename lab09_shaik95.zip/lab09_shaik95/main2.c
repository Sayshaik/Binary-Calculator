#include <stdio.h>
#define INPUT_VARIABLE_COUNT 3
#define OUTPUT_VARIABLE_COUNT 1

void buildingleftside(int truthtable[][INPUT_VARIABLE_COUNT+OUTPUT_VARIABLE_COUNT]){
	int rowCount=1 <<INPUT_VARIABLE_COUNT;
	for(int i=0;i<rowCount;i++){
		for(int j=0; j<INPUT_VARIABLE_COUNT;j++){
			truthtable[i][j]=(i>>(INPUT_VARIABLE_COUNT-1-j)) & 1;
		}
	}
} 

void buildingRightside(int truthtable[][INPUT_VARIABLE_COUNT+OUTPUT_VARIABLE_COUNT]){
	int rowCount = 1<<INPUT_VARIABLE_COUNT;
	for(int i=0;i<rowCount;i++){
		int output;
			do{
				printf("Enter output value for the row %d output variable (0 or 1):",i);
				scanf("%d",&output);
				if(output!=0 && output!=1){
					printf("Invalid please enter 0 or 1.\n");
				}
			} while(output!=0 && output!=1);
			truthtable[i][INPUT_VARIABLE_COUNT]=output;
		}
}

void printingTruthtable(int truthtable[][INPUT_VARIABLE_COUNT+OUTPUT_VARIABLE_COUNT]){
	const char var[INPUT_VARIABLE_COUNT+OUTPUT_VARIABLE_COUNT]={'A','B','C','D'};
	for(int i = 0; i < INPUT_VARIABLE_COUNT; i++){
			printf("%c, ",var[i]);
		}
	printf(": ");
	for(int i=INPUT_VARIABLE_COUNT; i<INPUT_VARIABLE_COUNT+OUTPUT_VARIABLE_COUNT;i++){
		printf("%c", var[i]);
	}
	printf("\n");
	int rowCount= 1 << INPUT_VARIABLE_COUNT;

	for(int v = 0;v < rowCount;v++){
		for(int j=0;j<INPUT_VARIABLE_COUNT;j++){
			printf("%d, ",truthtable[v][j]);
		}
		printf(": %d\n", truthtable[v][INPUT_VARIABLE_COUNT]);
}
}

void printingMinterm(int truthtable[][INPUT_VARIABLE_COUNT+OUTPUT_VARIABLE_COUNT]){
	int rowCount=1<<INPUT_VARIABLE_COUNT;
	const char var[INPUT_VARIABLE_COUNT]={'A','B','C'};
	printf("Output of the Variable:");
	int f=1;
	for(int i=0;i<rowCount;i++){
		if(truthtable[i][INPUT_VARIABLE_COUNT]==1){
			if(!f){
				printf("+");
			}
			f=0;
			for(int x=0; x<INPUT_VARIABLE_COUNT;x++){
				if(truthtable[i][x]==0){
					printf("%c'",var[x]);
				} else{
					printf("%c", var[x]);
				}
			}
		}
	}
	printf("\n");
}

int main(void){
	setbuf(stdout,NULL);
	int TRUTH_TABLE_ROW_COUNT = 1 <<INPUT_VARIABLE_COUNT;
	int truthtable[TRUTH_TABLE_ROW_COUNT][INPUT_VARIABLE_COUNT+OUTPUT_VARIABLE_COUNT];
	for(int i=0;i<TRUTH_TABLE_ROW_COUNT;i++){
		for(int j=0; j<INPUT_VARIABLE_COUNT + OUTPUT_VARIABLE_COUNT;j++){
			truthtable[i][j]=0;
		}
	}

	int command;
	do{
		printf("Enter what type of command number you want to be done:\n");
		printf("0) Exit\n1) Canonical SoP\n");
		scanf("%d",&command);

		if(command==1){
			buildingleftside(truthtable);
			buildingRightside(truthtable);
			printingTruthtable(truthtable); 
			printingMinterm(truthtable);
		}
		else if(command!=0){
			printf("Please either choose 0 or 1\n");
		}
	} while(command!=0);
	
	return 0;
}
