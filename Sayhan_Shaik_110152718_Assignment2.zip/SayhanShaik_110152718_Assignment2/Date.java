package Main;

public class Date {
	private int day;
	private int month;
	private int year;
	
	public Date(int day, int month, int year) { //constructor that contains day, month, and year
		this.day=day;
		this.month=month;
		this.year=year;
	}
	
	public Date(Date guessedBirthday) {
		this.day=guessedBirthday.day;
		this.month=guessedBirthday.month;
		this.year=guessedBirthday.year;
	}
	
	public Date(String Stringdate) {
		if(Stringdate.contains("/")) { 
			String[] p =Stringdate.split("/");
			this.day=Integer.parseInt(p[0]);
			this.month=Integer.parseInt(p[1]);
			this.year=Integer.parseInt(p[2]);
		}
		else {
			String[] p=Stringdate.split(",");
			String StringMonth=p[0];
			this.day=Integer.parseInt(p[1].replace(","," "));
			this.year=Integer.parseInt(p[2]);
			this.month=MonthConversion(StringMonth);
		}
	}
	
	private int MonthConversion(String StringMonth) { // using a switch statement to translate the month entered into a number type shit
		return switch(StringMonth.toLowerCase()) {
		case "jan" -> 1;
		case "feb" -> 2;
		case "mar" -> 3;
		case "apr" -> 4;
		case "may" -> 5;
		case "jun" -> 6;
		case "jul" -> 7;
		case "aug" -> 8;
		case "sep" -> 9;
		case "oct" -> 10;
		case "nov" -> 11;
		case "dec" -> 12;
		default -> 0;
		};
	}
	
	@Override
	public String toString() {
		return String.format("%02d/%02d/%d",day,month,year);
	}
	
	public int getDay() {
		return day;
	}
	
	public int getMonth() { // setter and getter methods.
		return month;
	}
	
	public int getYear() {
		return year;
	}
	
	public void setDay(int day) {
		this.day=day;
	}
	
	public void setMonth(int month) {
		this.month=month;
	}
	
	public void setYear(int year) {
		this.year=year;
	}
	
	public boolean equals(Date date) {
		if(date==null) {
			return false;
		}
		return this.day==date.day && this.month==date.month && this.year==date.year;
	}
}
