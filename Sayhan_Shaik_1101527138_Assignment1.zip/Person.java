package Main;

public class Person  {   // making a person class

	private String name;
	private Date birthday;
	private String country;
	
	public Person(String name, Date birthday, String country) {
		this.name=name;
		this.birthday=birthday;
		this.country=country;
	}
	
	public Person(Person another) { //these are the constructors for the variables inside the person containing a name,birthday,country
		this.name=another.name;
		this.birthday=another.birthday;
		this.country=another.country;
	}
	
	public String getName() { // a setter and getter methods are created down here
		return name;
	}
	
	public Date getBirthday() {
		return birthday;
		}
	
	public String getCountry() {
		return country;
	}
	
	@Override
	public String toString() {
		return String.format("name is: "+name, "and was born on: "+birthday,"in: "+country);
	}
}
