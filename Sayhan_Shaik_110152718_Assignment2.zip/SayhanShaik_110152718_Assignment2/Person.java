package Main;
   
public abstract class Person {  // making a person class and use abstract
	    private String name;
	    private Date birthday;  
	    private String country;
	    private int difficulty;

	    public Person(String name, Date birthday, String country, int difficulty) {//constructors 
	        this.name = name;
	        this.birthday = new Date(birthday);
	        this.country = country;
	        setDifficulty(difficulty);
	    }

	    public Person(Person another) { //another constructor to create a new person by coping another person
	        this.name = another.name;
	        this.birthday = new Date(another.birthday);
	        this.country = another.country;
	        this.difficulty = another.difficulty;
	    }

	    public Person(int difficulty) {  // another constructor
	        setDifficulty(difficulty);
	    }

	    private void setDifficulty(int difficulty) { //setter method for difficulty
	        if(difficulty < 1 || difficulty > 3) {
	            throw new IllegalArgumentException("Difficulty must be between 1 and 3.");
	        }
	        this.difficulty = difficulty;
	    }

	    public abstract String personType(); // a method that returns a string
	    
	    public abstract Person clone();// another method that returns an object

	    public String welcomeMessage() {
	        return "Welcome to the game of guessing famous birthdays :) Guess the birthday of " + personType() + " named " + name + ".";
	    }

	    public String successMessage() {
	        return "Wow what a job !!!!!!! You have successfully guessed the birthday of " + toString() + "!";
	    }

	    public String getName() {  //getter methods and the rests below except for the to string
	        return name;
	    }

	    public Date getBirthday() {
	        return new Date(birthday); //  encapsulation
	    }

	    public String getCountry() {
	        return country;
	    }

	    public int getDifficulty() {
	        return difficulty;
	    }

	    @Override
	    public String toString() { //to string to provide a rep of person object
	        return name + ", born on " + birthday + " in " + country;
	    }

	}
