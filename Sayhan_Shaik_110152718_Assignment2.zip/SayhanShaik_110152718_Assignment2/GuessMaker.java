package Main;

import java.util.Scanner;

public class GuessMaker {
	private Person[] celebrities;
    private int currentPerson;
    private int countchecker; // checks the number of elements in the array

	
	public GuessMaker(Person c1, Person c2, Person c3) {
		celebrities = new Person[10]; 
        celebrities[0] = c1;
        celebrities[1] = c2;
        celebrities[2] = c3;
        countchecker = 3;

	}
	
	public void addPerson(Person person) {
		if (countchecker < celebrities.length) { // if used to add names into the array
            celebrities[countchecker] = person;
            countchecker++;
        }

	}
	
	public void startGame() {
		Scanner key = new Scanner(System.in); // creating a scanner to read the inputs from the user
        boolean playing = true;

        while (playing) {
            System.out.println("Choose a person to guess their birthday:");
            for (int i = 0; i < countchecker; i++) { // makes sure it is less than the actual length and makes sure to print all the celebs printed
                System.out.println((i + 1) + ") " + celebrities[i].getName() + " from " + celebrities[i].getCountry());
            }
            System.out.print("Enter the number of your choice or enter 'Q' to exit and quit the game: ");
            String choice = key.nextLine(); // which reads if we want to quit or not 

            if (choice.equalsIgnoreCase("Q")) {
                System.out.println("Thanks for playing the game :) ");
                break;
            }

            try {
                currentPerson = Integer.parseInt(choice) - 1; 
                if (currentPerson < 0 || currentPerson >=countchecker) {
                    System.out.println("Invalid choice. Try again.");
                    continue;
                }
            } catch (NumberFormatException e) {  //if our format for the date is wrong
                System.out.println("Invalid input. Try again.");
                continue;
            }

            Person selectedPerson = celebrities[currentPerson];
            Date actualBirthdayofCeleb = selectedPerson.getBirthday();
            boolean correct = false;

            while (!correct) {
                System.out.print("Guess the birthday of " + selectedPerson.getName() + " (format: DD/MM/YYYY) or type 'Q' to exit and quit playing: ");
                String guess = key.nextLine();

                if (guess.equalsIgnoreCase("Q")) {
                    System.out.println("Thanks for playing the game program is being exited! ");
                    playing = false;
                    break;
                }

                try {
                    Date guessDate = new Date(guess);

                    if (guessDate.equals(actualBirthdayofCeleb)) {   // will start checking and comparing the dates inputed and if it later or earlier than the date entered by us.
                        System.out.println("Congratulations! Correct guess!");
                        correct = true;
                    } else if (guessDate.getYear() > actualBirthdayofCeleb.getYear() || 
                               (guessDate.getYear() == actualBirthdayofCeleb.getYear() && guessDate.getMonth() > actualBirthdayofCeleb.getMonth()) ||
                               (guessDate.getYear() == actualBirthdayofCeleb.getYear() && guessDate.getMonth() == actualBirthdayofCeleb.getMonth() && guessDate.getDay() > actualBirthdayofCeleb.getDay())) {
                        System.out.println("Incorrect guess-TRY guessing an earlier date.");
                    } else {
                        System.out.println("Incorrect guess-TRY guessing a later date.");
                    }
                } catch (Exception e) {
                    System.out.println("Invalid date format, Should not be written like that");
                }
            }
        }

        key.close(); // closing the scanner
	}

	
	//public static void main(String[] args) {
	//	Person c1 = new Person("Madelyn Cline",new Date(21,12,1997),"United States of America");
		//Person c2 = new Person("Cristiano Ronaldo", new Date(5,2,1985),"Portugal");
		//Person c3 = new Person("Paul Pogba", new Date(15,3,1993),"France");
		
		//GuessMaker game = new GuessMaker(c1,c2,c3);
		//game.startGame();
	//}
} // this assignment was fun coding we students love you guys as our TA. Keep up the great work fwaeeeh
