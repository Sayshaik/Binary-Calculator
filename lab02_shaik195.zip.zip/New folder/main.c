#include <stdio.h>

int main(void){
	for(int command=3;command!=0;){
	printf("0-EXIT 1-AND 2-OR\n");
	scanf("%d",&command);
		switch(command){

		case 0:
			printf("Thank you for using this program");
			break;
		case 1:
			int x;
			int y;
			scanf("%d",&x);
			scanf("%d",&y);
			printf("%d AND %d is %d\n",x,y,x & y);
			break;	
		case 2:
			int a;
			int b;
			scanf("%d",&a);
			scanf("%d",&b);
			printf("%d OR %d is %d\n",a,b, a||b);
			break;
		default:
			printf("Enter a valid number\n");
										
		}
	}	
	return 0;
}


