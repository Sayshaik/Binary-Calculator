#include <stdlib.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

#define MAX_BUFFER 1024

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s <IP> <Port>\n", argv[0]);
        exit(1);
    }

    int domain = AF_INET;
    int type = SOCK_STREAM;
    int protocol = 0;

    int server_sd = socket(domain, type, protocol);
    if (server_sd == -1) {
        perror("Error creating socket for server");
        exit(1);
    }

    printf("Server socket created with descriptor: %d\n", server_sd);

    struct in_addr server_sin_address;
    server_sin_address.s_addr = inet_addr(argv[1]);
    int server_sin_port = htons(atoi(argv[2]));

    struct sockaddr_in server_sin;
    server_sin.sin_family = domain;
    server_sin.sin_addr = server_sin_address;
    server_sin.sin_port = server_sin_port;

    
    if (bind(server_sd, (struct sockaddr *) &server_sin, sizeof(server_sin)) == -1) {
        perror("Error binding server to address");
        exit(1);
    }

    printf("Server bound to address %s:%d\n", argv[1], ntohs(server_sin.sin_port));

    
    if (listen(server_sd, 5) < 0) {
        perror("Server listen failed");
        exit(1);
    }

    printf("Server is listening for incoming connections...\n");

    struct sockaddr_in client_sin;
    socklen_t client_sin_len = sizeof(client_sin);

    while (1) {
        int client_sd = accept(server_sd, (struct sockaddr *) &client_sin, &client_sin_len);
        if (client_sd == -1) {
            perror("Error accepting client connection");
            continue;  
        }

        printf("Connection established with client %s:%d\n", inet_ntoa(client_sin.sin_addr), ntohs(client_sin.sin_port));

       
        pid_t pid = fork();
        if (pid == -1) {
            perror("Fork failed");
            continue;
        }

        if (pid == 0) {  
            close(server_sd);  
            char buffer[MAX_BUFFER];
            int bytes_received = recv(client_sd, buffer, sizeof(buffer), 0);
            if (bytes_received <= 0) {
                printf("Error or empty data received\n");
                close(client_sd);
                exit(0);
            }

            char username[50], password[50];
            int x, y;
            sscanf(buffer, "%s %s %d %d", username, password, &x, &y);

            if (strcmp(username, "comp2560") == 0 && strcmp(password, "f2022") == 0) {
              
                int result = x + y;  
                snprintf(buffer, sizeof(buffer), "Result: %d", result);
                send(client_sd, buffer, strlen(buffer), 0);
            } else {
               
                snprintf(buffer, sizeof(buffer), "Authentication failed!");
                send(client_sd, buffer, strlen(buffer), 0);
            }

            close(client_sd); 
            exit(0);  
        } else {
            close(client_sd);  
        }
    }

    return 0;
}




